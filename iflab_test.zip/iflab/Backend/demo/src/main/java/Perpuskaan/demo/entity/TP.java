package Perpuskaan.demo.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import java.util.Date;

@Data
@Entity
@Table(name = "tp")
public class TP {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tpid")
    private Integer tpid;

    @Column(nullable = false, name = "judul")
    private String judul;

    @Column(name = "sub_judul")
    private String sub_judul;
    
    @Column(name = "kategori")
    private String kategori;

    @Column(name = "tanggal_post")
    private Date tanggal_post;

    @Column(name = "deadline_post")
    private Date deadline_post;

    @Column(name = "deskripsi")
    private String deskripsi;
    
}
