package Perpuskaan.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import Perpuskaan.demo.dto.request.TpCreateRequest;
import Perpuskaan.demo.entity.TP;


import Perpuskaan.demo.repository.TPRepository;
@Service
public class TPService {
    @Autowired
    private TPRepository tpRepository;

    public TP createTP(TpCreateRequest request){
            TP tp = new TP();
            TP.setJudul(request.getJudul());
            TP.setSubJudul(request.getSubJudul());
            TP.setKategori(request.getKategori());
            TP.setTanggalPost(request.getTanggalPost());
            TP.setDeadlineTp(request.getDeadlineTp());
            TP.setDeskripsi(request.getDeskripsi());
    }
}
