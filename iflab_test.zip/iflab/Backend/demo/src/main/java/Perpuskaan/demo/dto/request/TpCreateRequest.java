package Perpuskaan.demo.dto.request;

import lombok.Data;
import java.util.Date;

@Data
public class TpCreateRequest {
    private Integer tpid;
    private String judul;
    private String sub_judul;
    private String kategori;
    
    private Date tanggal_post;
    private Date deadline_tp;

    private String deskripsi_tp;
}
