package Perpuskaan.demo.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import jakarta.validation.Valid;

import Perpuskaan.demo.dto.response.TPCreateResponse;
import Perpuskaan.demo.dto.request.TPCreateRequest;
import Perpuskaan.demo.entity.TP;
import Perpuskaan.demo.service.TPService;
import Perpuskaan.demo.dto.request.TpCreateRequest;


@RestController
@RequestMapping("/api/tp") // Base URL: localhost:8080/api/buku
@CrossOrigin(origins = "*")  // PENTING: Biar bisa diakses dari Frontend (Vue/React)
public class TPController {

    private final TPService tpservice;

    // Constructor Injection (Best Practice daripada @Autowired di field)
    public TPController(TPService tpservice) {
        this.tpservice = tpservice;
    }

    @PostMapping("/create")
    public ResponseEntity<?> createTP(@Valid @RequestBody TpCreateRequest createRequest){
            try{
                TP newTp = TPService.createTP;
                return ResponseEntiry.status(HttpStatus.CREATED).body(newTP);
            } catch{
                return ResponseEntity.badRequest().body(e.getMessage())
            }
    }

    @GetMapping("/all")
    public List<TPCreateResponse> getAll() {
        return tpservice.getAll();
    }


}
